package com.foodtech.back.entity.payment;

public enum PaymentType {

    CARD,
    GOOGLE_PAY,
    APPLE_PAY
}
